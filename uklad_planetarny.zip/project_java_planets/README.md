# project_java_planets
Interaktywny układ planetarny

Funkcjonalności </br>
1.	GUI	10 pkt  	 </br>
2.	Program znajduje się repozytorium GIT	(bowiązkowe)  </br> 		
3.	Użycie GIT	4 pkt  	 </br>
4.	Poprawne zastosowanie teorii fizycznej do wykonywanych obliczeń	4 pkt  	 </br>
5.	Zapis i odczyt parametrów z pliku tekstowego	4 pkt	 </br>
6.	Płynna animacja ruchu planet	15 pkt	 </br>
7.	Działający przycisk ON/OFF	2 pkt	 </br>
8.	Możliwość dodawania obiektów (słońca, planety, księżyce)	3 pkt </br>
9.	Wybór koloru dodawanych obiektów	1 pkt		 </br>
10.	Wybór masy dodawanych obiektów	1 pkt		 </br>
11.	Dodawanie obiektów do planszy kliknięciem myszy	2 pkt		 </br>
12.	Przesuwanie planszy z obiektami (WSAD)	1 pkt	 </br>	
13.	Rysowanie orbit dla planet	2 pkt		</br>
14.	Możliwość utworzenia nowego projektu (czyszczenie planszy)	1 pkt		 </br>
15.	Obsługa zderzeń planet (Ewentualnie) </br>
16.	Program wielojęzyczny	(Ewentualnie) </br>
