package pojavaKarabowiczCybulska.simulation;


public class MoveSimulationPanel
{
   /* private SimulationMainPanel simulationMainPanel;
    private float x, y; //actual position in space
    private float dispX, dispY; //where its drawn at on screen

    public MoveSimulationPanel()
    {
        this.x = 0;
        this.y = 0;
        this.dispX = 0;
        this.dispY = 0;
    }

    private void getKeyboardInput()
    {
        //Moving the camera
        //WASD KEYS
        if (handler.getKeyManager().up && !handler.getKeyManager().down)
            handler.SimulationMainPanel.move(0, -10);
        if (handler.getKeyManager().down && !handler.getKeyManager().up)
            handler.getCamera().move(0, 10);
        if (handler.getKeyManager().left && !handler.getKeyManager().right)
            handler.getCamera().move(-10, 0);
        if (handler.getKeyManager().right && !handler.getKeyManager().left)
            handler.getCamera().move(10, 0);
    }*/

}
